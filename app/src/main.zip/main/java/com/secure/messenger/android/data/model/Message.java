package com.secure.messenger.android.data.model;

import java.time.LocalDateTime;

/**
 * Клас моделі повідомлення
 */
public class Message {

    // Ідентифікатор повідомлення
    private String id;

    // Ідентифікатор відправника
    private String senderId;

    // Ім'я відправника
    private String senderName;

    // Ідентифікатор отримувача (для прямих повідомлень)
    private String recipientId;

    // Ім'я отримувача (для прямих повідомлень)
    private String recipientName;

    // Ідентифікатор групи (для групових повідомлень)
    private String groupId;

    // Назва групи (для групових повідомлень)
    private String groupName;

    // Тип повідомлення (TEXT, IMAGE, DOCUMENT, VOICE, REPORT)
    private MessageType type;

    // Зашифрований вміст повідомлення
    private byte[] encryptedContent;

    // Розшифрований вміст повідомлення (для відображення)
    private byte[] decryptedContent;

    // Статус повідомлення (SENDING, SENT, DELIVERED, READ, FAILED)
    private MessageStatus status;

    // Час створення повідомлення
    private LocalDateTime createdAt;

    // Час, коли повідомлення було прочитане
    private LocalDateTime readAt;

    // Помилка, якщо виникла при відправленні
    private String errorMessage;

    // Локальний ідентифікатор для відстеження повідомлень, які ще не відправлені
    private String localId;

    /**
     * Конструктор за замовчуванням
     */
    public Message() {
    }

    /**
     * Конструктор для прямого повідомлення
     */
    public Message(String senderId, String senderName, String recipientId, String recipientName,
                   MessageType type, byte[] encryptedContent) {
        this.senderId = senderId;
        this.senderName = senderName;
        this.recipientId = recipientId;
        this.recipientName = recipientName;
        this.type = type;
        this.encryptedContent = encryptedContent;
        this.status = MessageStatus.SENDING;
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Конструктор для групового повідомлення
     */
    public Message(String senderId, String senderName, String groupId, String groupName,
                   MessageType type, byte[] encryptedContent) {
        this.senderId = senderId;
        this.senderName = senderName;
        this.groupId = groupId;
        this.groupName = groupName;
        this.type = type;
        this.encryptedContent = encryptedContent;
        this.status = MessageStatus.SENDING;
        this.createdAt = LocalDateTime.now();
    }

    /**
     * @return ідентифікатор повідомлення
     */
    public String getId() {
        return id;
    }

    /**
     * @param id ідентифікатор повідомлення
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return ідентифікатор відправника
     */
    public String getSenderId() {
        return senderId;
    }

    /**
     * @param senderId ідентифікатор відправника
     */
    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    /**
     * @return ім'я відправника
     */
    public String getSenderName() {
        return senderName;
    }

    /**
     * @param senderName ім'я відправника
     */
    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    /**
     * @return ідентифікатор отримувача
     */
    public String getRecipientId() {
        return recipientId;
    }

    /**
     * @param recipientId ідентифікатор отримувача
     */
    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    /**
     * @return ім'я отримувача
     */
    public String getRecipientName() {
        return recipientName;
    }

    /**
     * @param recipientName ім'я отримувача
     */
    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    /**
     * @return ідентифікатор групи
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * @param groupId ідентифікатор групи
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * @return назва групи
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * @param groupName назва групи
     */
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    /**
     * @return тип повідомлення
     */
    public MessageType getType() {
        return type;
    }

    /**
     * @param type тип повідомлення
     */
    public void setType(MessageType type) {
        this.type = type;
    }

    /**
     * @return зашифрований вміст повідомлення
     */
    public byte[] getEncryptedContent() {
        return encryptedContent;
    }

    /**
     * @param encryptedContent зашифрований вміст повідомлення
     */
    public void setEncryptedContent(byte[] encryptedContent) {
        this.encryptedContent = encryptedContent;
    }

    /**
     * @return розшифрований вміст повідомлення
     */
    public byte[] getDecryptedContent() {
        return decryptedContent;
    }

    /**
     * @param decryptedContent розшифрований вміст повідомлення
     */
    public void setDecryptedContent(byte[] decryptedContent) {
        this.decryptedContent = decryptedContent;
    }

    /**
     * @return статус повідомлення
     */
    public MessageStatus getStatus() {
        return status;
    }

    /**
     * @param status статус повідомлення
     */
    public void setStatus(MessageStatus status) {
        this.status = status;
    }

    /**
     * @return час створення повідомлення
     */
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * @param createdAt час створення повідомлення
     */
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * @return час, коли повідомлення було прочитане
     */
    public LocalDateTime getReadAt() {
        return readAt;
    }

    /**
     * @param readAt час, коли повідомлення було прочитане
     */
    public void setReadAt(LocalDateTime readAt) {
        this.readAt = readAt;
    }

    /**
     * @return текст помилки
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage текст помилки
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * @return локальний ідентифікатор повідомлення
     */
    public String getLocalId() {
        return localId;
    }

    /**
     * @param localId локальний ідентифікатор повідомлення
     */
    public void setLocalId(String localId) {
        this.localId = localId;
    }

    /**
     * Перевіряє, чи є повідомлення груповим
     * @return true, якщо повідомлення групове
     */
    public boolean isGroupMessage() {
        return groupId != null && !groupId.isEmpty();
    }

    /**
     * Перевіряє, чи я є відправником повідомлення
     * @param myUserId мій ідентифікатор користувача
     * @return true, якщо я відправник
     */
    public boolean isFromMe(String myUserId) {
        return senderId != null && senderId.equals(myUserId);
    }

    /**
     * Отримує текстовий вміст повідомлення
     * @return текстовий вміст або null, якщо тип не TEXT
     */
    public String getTextContent() {
        if (type == MessageType.TEXT && decryptedContent != null) {
            return new String(decryptedContent);
        }
        return null;
    }

    /**
     * Отримує час у форматі "HH:MM"
     * @return відформатований час
     */
    public String getFormattedTime() {
        if (createdAt == null) {
            return "";
        }
        return String.format("%02d:%02d", createdAt.getHour(), createdAt.getMinute());
    }

    /**
     * Перелік типів повідомлень
     */
    public enum MessageType {
        TEXT, IMAGE, DOCUMENT, VOICE, REPORT
    }

    /**
     * Перелік статусів повідомлень
     */
    public enum MessageStatus {
        SENDING, SENT, DELIVERED, READ, FAILED
    }
}