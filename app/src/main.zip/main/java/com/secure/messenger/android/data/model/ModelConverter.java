package com.secure.messenger.android.data.model;

import com.secure.messenger.android.data.local.entity.ChatGroupEntity;
import com.secure.messenger.android.data.local.entity.MessageEntity;
import com.secure.messenger.android.data.local.entity.UserEntity;
import com.secure.messenger.proto.ChatGroupResponse;
import com.secure.messenger.proto.GroupMember;
import com.secure.messenger.proto.MessageContent;
import com.secure.messenger.proto.MessageResponse;
import com.secure.messenger.proto.UserInfo;
import com.secure.messenger.proto.UserProfile;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/**
 * Утилітний клас для конвертації моделей між різними шарами додатка
 */
public class ModelConverter {

    // Конвертація користувачів

    /**
     * Конвертує UserProfile з gRPC у сутність UserEntity
     */
    public static UserEntity convertToUserEntity(UserProfile profile) {
        return new UserEntity(
                profile.getUserId(),
                profile.getUsername(),
                profile.getPhoneNumber(),
                profile.getStatus(),
                profile.getPublicKey().toByteArray(),
                convertTimestampToLocalDateTime(System.currentTimeMillis()), // Поточний час
                false // За замовчуванням не є контактом
        );
    }

    /**
     * Конвертує UserInfo з gRPC у сутність UserEntity
     */
    public static UserEntity convertToUserEntity(UserInfo userInfo) {
        LocalDateTime lastActive = userInfo.hasLastActive() ?
                convertTimestampToLocalDateTime(userInfo.getLastActive()) : null;

        return new UserEntity(
                userInfo.getId(),
                userInfo.getUsername(),
                userInfo.getPhoneNumber(),
                userInfo.getStatus(),
                userInfo.hasPublicKey() ? userInfo.getPublicKey().toByteArray() : null,
                lastActive,
                false // За замовчуванням не є контактом
        );
    }

    /**
     * Конвертує UserEntity в модель User для презентаційного шару
     */
    public static User convertToUser(UserEntity entity) {
        if (entity == null) {
            return null;
        }

        return new User(
                entity.getId(),
                entity.getUsername(),
                entity.getPhoneNumber(),
                entity.getStatus(),
                entity.getPublicKey(),
                entity.getLastActive(),
                entity.isContact()
        );
    }

    /**
     * Конвертує список UserEntity в список User
     */
    public static List<User> convertToUsers(List<UserEntity> entities) {
        List<User> users = new ArrayList<>();
        if (entities != null) {
            for (UserEntity entity : entities) {
                users.add(convertToUser(entity));
            }
        }
        return users;
    }

    // Конвертація повідомлень

    /**
     * Конвертує MessageResponse з gRPC у сутність MessageEntity
     */
    public static MessageEntity convertToMessageEntity(MessageResponse response) {
        String messageId = response.getId();
        String senderId = response.getSenderId();
        String recipientId = response.hasRecipientId() ? response.getRecipientId() : null;
        String groupId = response.hasGroupId() ? response.getGroupId() : null;

        MessageContent content = response.getContent();
        String messageType = content.getType().name();
        byte[] encryptedContent = content.getEncryptedData().toByteArray();

        LocalDateTime createdAt = convertTimestampToLocalDateTime(response.getCreatedAt());
        LocalDateTime expiresAt = createdAt.plusDays(1); // За замовчуванням повідомлення живе 1 день

        return new MessageEntity(
                messageId,
                senderId,
                recipientId,
                groupId,
                messageType,
                encryptedContent,
                createdAt,
                expiresAt,
                false, // За замовчуванням не прочитане
                true,  // За замовчуванням надіслане
                true   // За замовчуванням доставлене
        );
    }

    /**
     * Конвертує MessageEntity в модель Message для презентаційного шару
     */
    public static Message convertToMessage(MessageEntity entity) {
        if (entity == null) {
            return null;
        }

        return new Message(
                entity.getId(),
                entity.getSenderId(),
                entity.getRecipientId(),
                entity.getGroupId(),
                entity.getMessageType(),
                entity.getEncryptedContent(),
                entity.getCreatedAt(),
                entity.getExpiresAt(),
                entity.isRead(),
                entity.isSent(),
                entity.isDelivered()
        );
    }

    /**
     * Конвертує список MessageEntity в список Message
     */
    public static List<Message> convertToMessages(List<MessageEntity> entities) {
        List<Message> messages = new ArrayList<>();
        if (entities != null) {
            for (MessageEntity entity : entities) {
                messages.add(convertToMessage(entity));
            }
        }
        return messages;
    }

    // Конвертація груп

    /**
     * Конвертує ChatGroupResponse з gRPC у сутність ChatGroupEntity
     */
    public static ChatGroupEntity convertToChatGroupEntity(ChatGroupResponse response) {
        return new ChatGroupEntity(
                response.getId(),
                response.getName(),
                response.getDescription(),
                response.getAdminId(),
                response.getReportEnabled(),
                response.getMemberCount(),
                null, // Шифрований ключ групи буде встановлено пізніше
                convertTimestampToLocalDateTime(response.getCreatedAt()),
                LocalDateTime.now() // Поточний час як час оновлення
        );
    }

    /**
     * Конвертує ChatGroupEntity в модель ChatGroup для презентаційного шару
     */
    public static ChatGroup convertToChatGroup(ChatGroupEntity entity) {
        if (entity == null) {
            return null;
        }

        return new ChatGroup(
                entity.getId(),
                entity.getName(),
                entity.getDescription(),
                entity.getAdminId(),
                entity.isReportEnabled(),
                entity.getMemberCount(),
                entity.getEncryptedGroupKey(),
                entity.getCreatedAt(),
                entity.getUpdatedAt()
        );
    }

    /**
     * Конвертує список ChatGroupEntity в список ChatGroup
     */
    public static List<ChatGroup> convertToChatGroups(List<ChatGroupEntity> entities) {
        List<ChatGroup> groups = new ArrayList<>();
        if (entities != null) {
            for (ChatGroupEntity entity : entities) {
                groups.add(convertToChatGroup(entity));
            }
        }
        return groups;
    }

    // Допоміжні методи

    /**
     * Конвертує мітку часу (мілісекунди від епохи) в LocalDateTime
     */
    private static LocalDateTime convertTimestampToLocalDateTime(long timestamp) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());
    }
}